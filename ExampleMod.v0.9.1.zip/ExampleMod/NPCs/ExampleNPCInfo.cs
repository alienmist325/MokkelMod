using Terraria.ModLoader;

namespace ExampleMod.NPCs
{
	public class ExampleNPCInfo : NPCInfo
	{
		public bool eFlames = false;
	}
}