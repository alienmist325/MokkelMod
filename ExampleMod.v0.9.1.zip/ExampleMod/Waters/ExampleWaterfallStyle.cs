using Terraria;
using Terraria.ModLoader;

namespace ExampleMod.Waters
{
	public class ExampleWaterfallStyle : ModWaterfallStyle
	{
		
	}
}